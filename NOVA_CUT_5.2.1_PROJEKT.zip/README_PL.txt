NOVA CUT 5.2.1 — POPRAWKA PUSTEGO EKRANU
=======================================

DLACZEGO WERSJA 5.2 MOGŁA POKAZYWAĆ PUSTY EKRAN?
Jeśli w instalatorze zabrakło app/index.html, Electron nie wyświetlał informacji o błędzie.
Nie da się stwierdzić, czy to faktyczna przyczyna bez logu z Twojego komputera.

CO POPRAWIONO:
1. Wyraźny ekran błędu, jeśli index.html się nie wczyta.
2. Log uruchomienia w katalogu danych aplikacji (menu Pomoc -> Otwórz folder diagnostyki).
3. Test kompletności projektu przed kompilacją; brak pliku app/index.html zatrzymuje build.
4. Skrót F12 / Ctrl+Shift+I otwiera narzędzia programistyczne.
5. Możliwość uruchomienia z --disable-gpu w razie problemów sterownika graficznego.

CO WYSŁAĆ DO GITHUB:
Wypakuj całe archiwum ZIP, a do repozytorium wgraj wszystkie pliki i foldery,
W TYM folder app i app/index.html oraz folder scripts z check-project.js.
Nie przesyłaj do GitHub samego ZIP-a zamiast jego zawartości.
Sprawdź w zakładce Code czy widoczna jest ścieżka app/index.html.

Uruchom GitHub Actions -> NOVA CUT - Windows EXE -> Run workflow.
Pobierz Artefakt NOVA-CUT-Windows-5.2.1-FIX.
Uruchom nową wersję Portable albo instalator.

JAK ZNALEŹĆ LOG:
W menu aplikacji naciśnij Alt -> Pomoc -> Otwórz folder diagnostyki.
Otwórz novacut-startup.log i skopiuj treść komunikatu (bez prywatnych ścieżek, jeśli wolisz).
Jeśli aplikacja się nie wczytuje, nowy ekran diagnostyczny pokaże tę ścieżkę.

GPU:
Jeżeli edytor wciąż jest pusty, uruchom wersję Portable.exe przez PowerShell:
& ".\NOVA-CUT-5.2.1-Portable-5.2.1.exe" --disable-gpu
(uruchom PowerShell w folderze, w którym znajduje się EXE).

Uwaga: aktualizacja eliminuje cichy brak strony, ale nie gwarantuje, że każda przyczyna
czarnego/pustego okna zostanie automatycznie naprawiona.
